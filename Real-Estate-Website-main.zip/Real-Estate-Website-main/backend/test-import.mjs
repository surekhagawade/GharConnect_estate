import FirecrawlApp from '@mendable/firecrawl-js';
console.log('FirecrawlApp import successful');
console.log('Constructor available:', typeof FirecrawlApp);
